package WebDriverEX;

import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class OpenMultipleBrowsers {

	public static void main(String[] args) {		
		WebDriver driver;		
		System.out.println("Enter browser type: ");
		Scanner sc = new Scanner(System.in);
		String brType = sc.next();
		brType = brType.toUpperCase();
			switch(brType)
			{
			case "FF":
				  driver=new FirefoxDriver();
				  driver.get("http://www.google.com");
				  System.out.println(driver.getTitle());
				  driver.quit();
				   break;
			case "HTML":
				  driver=new HtmlUnitDriver();				  
				  driver.get("http://www.google.com");
				  System.out.println(driver.getTitle());
				  driver.quit();
				  break;
			case "IE":
				System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
				  driver=new InternetExplorerDriver();
				  driver.get("http://www.icicibank.com");
				  System.out.println(driver.getTitle());
				  driver.quit();
				  break;
			case "CHROME":
				System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
				driver=new ChromeDriver();
	              driver.get("http://www.google.com");
	              System.out.println(driver.getTitle());
	              driver.quit();
	              break;
			}
	}

}
