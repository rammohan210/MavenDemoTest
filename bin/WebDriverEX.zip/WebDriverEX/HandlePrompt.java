package WebDriverEX;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HandlePrompt {

	public static void main(String[] args) {
		
		WebDriver driver=new FirefoxDriver();
		
		driver.get("file:///C:/Users/tm11/Desktop/confirm.html");		
		// find the button
		driver.findElement(By.xpath("//button")).click();		
			
		Alert obj = driver.switchTo().alert();
		System.out.println(obj.getText());

		//Click OK
		obj.accept();
		
		// click on cancel button
		//obj.dismiss();

	}

}
