package javaadvanced;

public class Class2 {
	
	protected int add(int x, int y)
	{
		int z;
		System.out.println("Class2");
		z = x + y;
		return z;		
	}
}
