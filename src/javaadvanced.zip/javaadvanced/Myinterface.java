package javaadvanced;

public interface Myinterface {
	
	public void m1(int x, int y);
	
	public void m2(int x, int y);
	
	public void m3(int x, int y);

}
