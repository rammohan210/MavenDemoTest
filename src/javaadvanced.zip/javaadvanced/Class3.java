package javaadvanced;
import javabasics.JavabClass1;

public class Class3 {
	
	public void add(int x, int y)
	 {
		 int z;
		 z = x + y;
		 System.out.println("Addn of 2 val is: "+z);
	 }

	public static void main(String[] args) {
		
		//Class3 obj1 = new Class3();
		//obj1.add(10, 20);
		
		JavabClass1 obj2 = new JavabClass1(50);
		//obj2.mul(20, 5);
		
		
		
		
		
		
		
		

	}

}
